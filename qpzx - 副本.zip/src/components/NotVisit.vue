<template>
  <div class="box">
    <DaibanMessage v-if="show" :type="type" />
    <header class="main-header">
      <ul>
        <li style="margin-left:30px">
          <!-- <i></i> -->
          <span>今日新分</span>
        </li>
      </ul>
    </header>
    <section class="main-section">
      <div class="surplus">
        <div class="main-section-bottom">
          <div class="contaner">
            <div style="height:30px;"></div>
            <Form :model="form" :label-width="80">
              <Row>
                <Col span="4">
                  <FormItem style="width:230px;">
                    <Input v-model="form.name" placeholder="学员姓名" @on-change="seekKuhu"></Input>
                  </FormItem>
                </Col>
                <Col span="4">
                  <FormItem style="width:230px;">
                    <Input v-model="form.mobile" placeholder="注册手机" @on-change="seekKuhu"></Input>
                  </FormItem>
                </Col>
                <Col span="4">
                  <FormItem>
                    <Select
                      v-model="form.refer"
                      style="width:150px"
                      @on-change="seekKuhu"
                      placeholder="渠道"
                    >
                      <Option
                        v-for="(list,i) in refer"
                        :key="i"
                        :value="list.id"
                      >{{list.channel_title}}</Option>
                    </Select>
                  </FormItem>
                </Col>
                <Col span="4">
                  <FormItem>
                    <Select
                      v-model="form.grade"
                      style="width:150px"
                      @on-change="seekKuhu"
                      placeholder="年级"
                    >
                      <Option :value="1">一年级</Option>
                      <Option :value="2">二年级</Option>
                      <Option :value="3">三年级</Option>
                      <Option :value="4">四年级</Option>
                      <Option :value="5">五年级</Option>
                      <Option :value="6">六年级</Option>
                      <Option :value="7">七年级</Option>
                      <Option :value="8">八年级</Option>
                      <Option :value="9">九年级</Option>
                    </Select>
                  </FormItem>
                </Col>
                <Col span="4">
                  <FormItem>
                    <Select
                      v-model="form.subject"
                      style="width:150px"
                      @on-change="seekKuhu"
                      placeholder="意向科目"
                    >
                      <Option :value="i" v-for="(list,i) in subjectList">{{list}}</Option>
                    </Select>
                  </FormItem>
                </Col>
                <Col span="4">
                  <FormItem>
                    <Select
                      v-model="form.transfer"
                      style="width:150px"
                      @on-change="seekKuhu"
                      placeholder="流转类型"
                    >
                      <Option v-for="(list,i) in transfer" :key="i" :value="i">{{list}}</Option>
                    </Select>
                  </FormItem>
                </Col>
                <Col span="8">
                  <FormItem>
                    <div class="dateplc">
                      <DatePicker
                        v-model="startTime"
                        type="date"
                        placeholder="注册时间"
                        style="width: 200px"
                        @on-change="getTimes"
                      ></DatePicker>
                      <DatePicker
                        v-model="endTime"
                        type="date"
                        placeholder="注册时间"
                        style="width: 200px"
                        @on-change="getTimes"
                      ></DatePicker>
                    </div>
                  </FormItem>
                </Col>
                <Col span="4" style="margin-left:30px">
                  <Button type="primary" @click="clear">清除</Button>
                </Col>
              </Row>
            </Form>
            <Table
              border
              :columns="columns"
              :data="NotdataArr"
              @on-selection-change="selectionChange"
              height="500"
            ></Table>
            <Page
              @on-change="pageChange"
              :total="total"
              :current="currentPage"
              :page-size="pageSize"
              show-total
              show-elevator
              class="ive-page"
            />
          </div>
        </div>
      </div>
    </section>
    <Loading v-show="isLoading" />
    <MineclientMessage :type="type" v-if="showMine" />
  </div>
</template>

<script>
import { mapState, mapActions, mapMutations, mapGetters } from "vuex";
import DaibanMessage from "../uilt/newErweima/DaibanMessage";
import MineclientMessage from "./minecllient/MineclientMessage";
import Loading from "../uilt/loading/loading";
import storage from "../uilt/storage";
export default {
  components: {
    DaibanMessage,
    Loading,
    MineclientMessage
  },
  mounted() {
    this.setCurrentPage(1);
    this.isLoading = true;
    this.getXinfenList().then(res => {
      this.isLoading = false;
    });
  },
  data() {
    return {
      showMine: false,
      subjectList: storage.getDaiban().screen_list.subject,
      transfer: storage.getDaiban().screen_list.transfer,
      stage: storage.getDaiban().screen_list.stage,
      startTime: "",
      endTime: "",
      show: false,
      isLoading: false,
      type: {
        status: "notvisit",
        page: 1
      },
      show: false,
      form: {},
      columns: [
        { type: "selection", width: 60 },
        { title: "学员姓名", key: "student_name" },
        { title: "注册手机", key: "mobile" },
        { title: "购买课程", key: "product_subject" },
        { title: "年级", key: "grade" },
        { title: "意向科目", key: "subject" },
        // { title: "渠道优先级", key: "subject" },
        // { title: "渠道类型", key: "refer" },
        { title: "渠道来源", key: "refer" },
        { title: "跟进状态", key: "follow_status" },
        // { title: "学习阶段", key: "follow_status" },
        { title: "呼出情况", key: "many_calls" },
        { title: "流转类型", key: "transfer" },
        { title: "分配时间", key: "receive_time" },
        { title: "注册时间", key: "create_time" },
        {
          title: "操作",
          key: "action",
          align: "center",
          render: (h, params) => {
            return h("div", [
              // h(
              //   "Button",
              //   {
              //     props: {
              //       type: "text",
              //       size: "small"
              //     },
              //     on: {
              //       click: () => {
              //         this.audition(params.row);
              //       }
              //     }
              //   },
              //   "试听"
              // ),
              h(
                "Button",
                {
                  props: {
                    type: "text",
                    size: "small"
                  },
                  on: {
                    click: () => {
                      this.getBtnClick3(params.row);
                    }
                  }
                },
                "跟进"
              ),
              h(
                "Button",
                {
                  props: {
                    type: "text",
                    size: "small"
                  },
                  on: {
                    click: () => {
                      this.getBtnClick4(params.row);
                    }
                  }
                },
                "呼出"
              )
            ]);
          }
        }
      ]
    };
  },
  methods: {
    //设置返回的时间
    datePicker(time) {
      var d = new Date(time);
      let shi = d.getHours();
      let fen = d.getMinutes();
      let miao = d.getSeconds();
      if (shi < 10) shi = "0" + shi;
      if (fen < 10) fen = "0" + fen;
      if (miao < 10) miao = "0" + miao;
      d = d.getFullYear() + "-" + (d.getMonth() + 1) + "-" + d.getDate();
      return d;
    },
    //日期选择器
    getTimes() {
      if (this.startTime && this.endTime) {
        this.form.create_time_start = this.datePicker(this.startTime);
        this.form.create_time_end = this.datePicker(this.endTime);
        this.seekKuhu();
      }
    },
    //试听
    audition(item) {
      this.setNotvisitTypes(item);
      this.showMine = true;
      this.type.classify = "audition";
      this.type.form = this.form;
      this.type.page = this.currentPage;
      this.type.data = { ...this.notvisitType };
    },
    //清空查询条件
    clear() {
      this.form = {};
      this.startTime = "";
      this.endTime = "";
      this.seekKuhu();
    },
    //搜索
    seekKuhu() {
      let page = 1;
      let currentPage = this.currentPage;
      if (currentPage > 1) {
        this.setCurrentPage(page);
      }
      this.isLoading = true;
      this.getXinfenList({ ...this.form, page }).then(res => {
        this.setCurrentPage(page);
        this.isLoading = false;
      });
    },
    ...mapActions(["getXinfenList", "RingUp"]),
    ...mapMutations(["setCurrentPage", "setNotvisitTypes"]),
    //全选反选
    selectionChange() {},
    //跟进
    getBtnClick3(item) {
      this.setNotvisitTypes(item);
      this.show = true;
      this.type.classify = "followUp";
      this.type.page = this.currentPage;
      this.type.form = { ...this.form };
      this.type.data = { ...this.notvisitType };
    },
    //呼出
    getBtnClick4(item) {
      this.setNotvisitTypes(item);
      this.show = true;
      this.type.classify = "followUp";
      this.type.data = { ...this.notvisitType };
      if(typeof item.spare_phone == 'undefined' ||item.spare_phone == "" || item.spare_phone == null){
        this.isLoading = true;
        this.RingUp({form:item})
        .then(res => {
          if (res.data.code == 200) {
            this.$Message.success("呼出成功");
          }
          if (res.data.code == 1000) {
            this.$Message.error({
              content: res.data.error,
              duration: 4
            });
          }
          this.isLoading = false;
        })
        .catch(e => {
          if (e) {
            this.isLoading = false;
          }
        });
      }else{
        this.type.classify = "ringupFollowUp";
      }
    },
    //分页
    pageChange(num) {
      this.setCurrentPage(num);
      this.isLoading = true;
      this.getXinfenList({ ...this.form }).then(res => {
        this.isLoading = false;
        this.setCurrentPage(num);
      });
    }
  },
  computed: {
    ...mapGetters(["NotdataArr", "notvisitType"]),
    ...mapState({
      data: state => state.notvisit.xinfenList,
      refer: state => state.notvisit.refer,
      currentPage: state => state.notvisit.currentPage,
      total: state => state.notvisit.total,
      pageSize: state => state.notvisit.pageSize
    })
  }
};
</script>
<style scoped>
.dateplc {
  display: flex;
}
</style>