<template>
  <div class="box">
    <div class="center">
      <img src="../assets/img/xiaoshou/png24.png" alt />
      <span>销售小姐姐们加油 ~</span>
    </div>
  </div>
</template>

<script>
export default {};
</script>

<style scoped>
.center span{
  margin-top: 30px;
}
.center {
  height: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
}
</style>