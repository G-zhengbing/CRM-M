<template>
  <div class="classstudents">
    <!-- 面包屑 -->
    <Crumbs>
      <template slot="title">我的预约单</template>
    </Crumbs>

    <!-- 卡片包裹 -->
    <Card class="card">
      <div style="text-align:center">
        <Tabs type="card" value="name1" @on-click="changeTab">
          <TabPane label="全部预约单" name="name1">
            <!-- <SelectBox
              @formData="formData"
              :classType="true"
              :chooseSubject="true"
              :lecturer="true"
              :classname="true"
              :tradingHour="true"
              :courseDates="true"
              :submissionTime="true"
              :auditionType="true"
              :condition="true"
            />-->
            <div class="title">
              <Form class="select" ref="formValidate" :model="formItem" inline>
                <FormItem>
                  <Input v-model="formItem.student_name" placeholder="学员姓名" style="width: 80px;"></Input>
                </FormItem>
                <FormItem>
                  <Input v-model="formItem.mobile" placeholder="注册手机" style="width: 80px;"></Input>
                </FormItem>
                <FormItem>
                  <Select v-model="formItem.type" placeholder="试听类型" style="width: 100px;">
                    <Option
                      :value="index"
                      v-for="(item,index) in selectState.type"
                      :key="index"
                    >{{item}}</Option>
                  </Select>
                </FormItem>
                <FormItem>
                  <Select v-model="formItem.appoint_status" placeholder="状态" style="width: 80px;">
                    <Option
                      :value="index"
                      v-for="(item,index) in selectState.appoint_status"
                      :key="index"
                    >{{item}}</Option>
                  </Select>
                </FormItem>
                <FormItem>
                  <Select v-model="formItem.grade" placeholder="选择年级" style="width: 100px;">
                    <Option
                      :value="index"
                      v-for="(item,index) in selectState.grade"
                      :key="index"
                    >{{item}}</Option>
                  </Select>
                </FormItem>
                <FormItem>
                  <Select v-model="formItem.subject" placeholder="选择科目" style="width: 100px;">
                    <Option
                      :value="index"
                      v-for="(item,index) in selectState.subject"
                      :key="index"
                    >{{item}}</Option>
                  </Select>
                </FormItem>
                <FormItem>
                  <DatePicker
                    v-model="formItem.allocateTime"
                    type="datetimerange"
                    placement="bottom-end"
                    placeholder="分配时间 - 分配时间"
                    style="width: 165px"
                    @on-change="changeAllocateTimeDate"
                  ></DatePicker>
                </FormItem>
                <FormItem>
                  <DatePicker
                    v-model="formItem.courseDates"
                    type="datetimerange"
                    placement="bottom-end"
                    placeholder="上课日期 - 上课日期"
                    @on-change="changeCourseData"
                    style="width: 165px"
                  ></DatePicker>
                </FormItem>
                <FormItem>
                  <DatePicker
                    v-model="formItem.submissionTime"
                    type="datetimerange"
                    placement="bottom-end"
                    placeholder="提交时间 - 提交时间"
                    @on-change="changeSubmissionTime"
                    style="width: 165px"
                  ></DatePicker>
                </FormItem>
                <FormItem>
                  <Button @click="deleteFormData" style="margin-left: 8px">清空选项</Button>
                </FormItem>
              </Form>
            </div>
            <TableBox :columns="columns" :dataList="dataList" />
            <PagingBox
              @changePages="changePages"
              :total="total"
              :per_page="per_page"
              :current_page="current_page"
              :last_page="last_page"
            />
          </TabPane>
          <TabPane label="今日上课提醒" name="name2">
            <!-- <SelectBox
              @formData="formData"
              :auditionType="true"
              :chooseSubject="true"
              :classType="true"
              :lecturer="true"
              :classname="true"
              :tradingHour="true"
              :submissionTime="true"
            />-->
            <div class="title">
              <Form class="select" ref="formValidate" :model="formItem" inline>
                <FormItem>
                  <Input v-model="formItem.student_name" placeholder="学员姓名" style="width: 80px;"></Input>
                </FormItem>
                <FormItem>
                  <Input v-model="formItem.mobile" placeholder="注册手机" style="width: 80px;"></Input>
                </FormItem>
                <FormItem>
                  <Select v-model="formItem.type" placeholder="试听类型" style="width: 100px;">
                    <Option
                      :value="index"
                      v-for="(item,index) in selectState.type"
                      :key="index"
                    >{{item}}</Option>
                  </Select>
                </FormItem>
                <FormItem>
                  <Select v-model="formItem.grade" placeholder="选择年级" style="width: 100px;">
                    <Option
                      :value="index"
                      v-for="(item,index) in selectState.grade"
                      :key="index"
                    >{{item}}</Option>
                  </Select>
                </FormItem>
                <FormItem>
                  <Select v-model="formItem.subject" placeholder="选择科目" style="width: 100px;">
                    <Option
                      :value="index"
                      v-for="(item,index) in selectState.subject"
                      :key="index"
                    >{{item}}</Option>
                  </Select>
                </FormItem>
                <FormItem>
                  <DatePicker
                    v-model="formItem.allocateTime"
                    type="datetimerange"
                    placement="bottom-end"
                    placeholder="分配时间 - 分配时间"
                    style="width: 165px"
                    @on-change="changeAllocateTimeDate"
                  ></DatePicker>
                </FormItem>
                <FormItem>
                  <DatePicker
                    v-model="formItem.submissionTime"
                    type="datetimerange"
                    placement="bottom-end"
                    placeholder="提交时间 - 提交时间"
                    @on-change="changeSubmissionTime"
                    style="width: 165px"
                  ></DatePicker>
                </FormItem>
                <FormItem>
                  <Button @click="deleteFormData" style="margin-left: 8px">清空选项</Button>
                </FormItem>
              </Form>
            </div>
            <TableBox :allocationData="'签到'" :columns="columns" :dataList="dataList" />
            <PagingBox
              @changePages="changePages"
              :total="total"
              :per_page="per_page"
              :current_page="current_page"
              :last_page="last_page"
            />
          </TabPane>
          <TabPane label="今日上课情况" name="name3">
            <!-- <SelectBox
              @formData="formData"
              :auditionType="true"
              :chooseSubject="true"
              :condition="true"
              :classType="true"
              :lecturer="true"
              :classname="true"
              :tradingHour="true"
              :submissionTime="true"
            />-->
            <div class="title">
              <Form class="select" ref="formValidate" :model="formItem" inline>
                <FormItem>
                  <Input v-model="formItem.student_name" placeholder="学员姓名" style="width: 80px;"></Input>
                </FormItem>
                <FormItem>
                  <Input v-model="formItem.mobile" placeholder="注册手机" style="width: 80px;"></Input>
                </FormItem>
                <FormItem>
                  <Select v-model="formItem.type" placeholder="试听类型" style="width: 100px;">
                    <Option
                      :value="index"
                      v-for="(item,index) in selectState.type"
                      :key="index"
                    >{{item}}</Option>
                  </Select>
                </FormItem>
                <FormItem>
                  <Select v-model="formItem.grade" placeholder="选择年级" style="width: 100px;">
                    <Option
                      :value="index"
                      v-for="(item,index) in selectState.grade"
                      :key="index"
                    >{{item}}</Option>
                  </Select>
                </FormItem>
                <FormItem>
                  <Select v-model="formItem.subject" placeholder="选择科目" style="width: 100px;">
                    <Option
                      :value="index"
                      v-for="(item,index) in selectState.subject"
                      :key="index"
                    >{{item}}</Option>
                  </Select>
                </FormItem>
                <FormItem>
                  <Select v-model="formItem.appoint_status" placeholder="状态" style="width: 80px;">
                    <Option
                      :value="index"
                      v-for="(item,index) in selectState.appoint_status"
                      :key="index"
                    >{{item}}</Option>
                  </Select>
                </FormItem>
                <FormItem>
                  <DatePicker
                    v-model="formItem.allocateTime"
                    type="datetimerange"
                    placement="bottom-end"
                    placeholder="分配时间 - 分配时间"
                    style="width: 165px"
                    @on-change="changeAllocateTimeDate"
                  ></DatePicker>
                </FormItem>
                <FormItem>
                  <DatePicker
                    v-model="formItem.submissionTime"
                    type="datetimerange"
                    placement="bottom-end"
                    placeholder="提交时间 - 提交时间"
                    @on-change="changeSubmissionTime"
                    style="width: 165px"
                  ></DatePicker>
                </FormItem>
                <FormItem>
                  <Button @click="deleteFormData" style="margin-left: 8px">清空选项</Button>
                </FormItem>
              </Form>
            </div>
            <TableBox :columns="columns" :dataList="dataList" />
            <PagingBox
              @changePages="changePages"
              :total="total"
              :per_page="per_page"
              :current_page="current_page"
              :last_page="last_page"
            />
          </TabPane>
        </Tabs>
      </div>
    </Card>
    <CallOut
      v-if="type == 'CallOut'"
      :row="row"
      :showMod="showMod"
      @changeShowMod="changeShowMod"
    />
    <Appraisal
      v-else-if="type == 'Appraisal'"
      :row="row"
      :showMod="showMod"
      @changeShowMod="changeShowMod"
    />
    <Signin
      v-else-if="type == 'Signin'"
      :row="row"
      :showMod="showMod"
      @changeShowMod="changeShowMod"
    />
    <Cancelreservation
      v-else-if="type == 'Cancelreservation'"
      :row="row"
      :showMod="showMod"
      @changeShowMod="changeShowMod"
    />
    <Loading v-show="isLoading" />
  </div>
</template>

<script>
import { mapState, mapMutations, mapActions, mapGetters } from "vuex";
import { MYRESERVATION, SCREENLIST } from "@/uilt/url/url";
import qs from "qs";

import MyReservation from "@/store/myreservation";
export default {
  computed: {
    ...mapState({
      refresh: state => state.currentPage.refresh,
      selectState: state => state.selectState
    })
  },
  data() {
    return {
      isLoading: false,
      columns: "",
      dataList: [],
      value: "name1", // 判断卡片选择状态
      mode: [], // formData数据
      total: 100,
      per_page: 10,
      current_page: 1,
      last_page: 1,
      formItem: {},
      columns1: [
        {
          type: "selection",
          width: 60,
          align: "center"
        },
        {
          title: "学员姓名",
          key: "student_name",
          align: "center",
          width: 100
        },
        {
          title: "注册手机",
          key: "mobile",
          align: "center",
          width: 140
        },
        {
          title: "试听类型",
          key: "type",
          align: "center",
          width: 100
        },
        {
          title: "试听课程",
          key: "course_name",
          align: "center",
          width: 160
        },
        {
          title: "年级",
          key: "grade",
          align: "center",
          width: 100
        },
        {
          title: "科目",
          key: "subject",
          align: "center",
          width: 100
        },
        {
          title: "教师",
          key: "name",
          align: "center",
          width: 100
        },
        {
          title: "上课日期",
          key: "date_time",
          align: "center",
          sortable: true,
          sortType: "asc",
          width: 140
        },
        {
          title: "上课时段",
          key: "time_slot",
          align: "center",
          width: 140
        },
        {
          type: "html",
          title: "状态",
          key: "appoint_status",
          align: "center",
          width: 120
        },
        {
          title: "预约提交时间",
          key: "create_time",
          align: "center",
          width: 180
        },
        {
          title: "备注",
          key: "note",
          align: "center",
          width: 100
        },
        {
          title: "操作",
          key: "operation",
          align: "center",
          fixed: "right",
          width: 210,
          render: (h, params) => {
            return h("div", [
              h(
                "Button",
                {
                  props: {
                    type: "text",
                    size: "small"
                  },
                  on: {
                    click: () => {
                      this.Signin(params.row);
                    }
                  }
                },
                "签到"
              ),
              h(
                "Button",
                {
                  props: {
                    type: "text",
                    size: "small"
                  },
                  on: {
                    click: () => {
                      this.Appraisal(params.row);
                    }
                  }
                },
                "查看测评"
              ),
              h(
                "Button",
                {
                  props: {
                    type: "text",
                    size: "small"
                  },
                  on: {
                    click: () => {
                      this.Cancelreservation(params.row);
                    }
                  }
                },
                "取消预约"
              ),
              h(
                "Button",
                {
                  props: {
                    type: "text",
                    size: "small"
                  },
                  on: {
                    click: () => {
                      this.CallOut(params.row);
                    }
                  }
                },
                "呼出"
              )
            ]);
          }
        }
      ],
      columns2: [
        {
          type: "selection",
          width: 60,
          align: "center"
        },
        {
          title: "学员姓名",
          key: "student_name",
          align: "center",
          width: 100
        },
        {
          title: "注册手机",
          key: "mobile",
          align: "center",
          width: 140
        },
        {
          title: "试听类型",
          key: "type",
          align: "center",
          width: 100
        },
        {
          title: "试听课程",
          key: "course_name",
          align: "center",
          width: 140
        },
        {
          title: "年级",
          key: "grade",
          align: "center",
          width: 100
        },
        {
          title: "科目",
          key: "subject",
          align: "center",
          width: 100
        },
        {
          title: "教师",
          key: "name",
          align: "center",
          width: 100
        },
        {
          title: "上课日期",
          key: "date_time",
          align: "center",
          sortable: true,
          sortType: "asc",
          width: 140
        },
        {
          title: "上课时段",
          key: "time_slot",
          align: "center",
          width: 140
        },
        {
          type: "html",
          title: "状态",
          key: "appoint_status",
          align: "center",
          width: 120
        },
        {
          title: "预约提交时间",
          key: "create_time",
          align: "center",
          width: 180
        },
        {
          title: "备注",
          key: "note",
          align: "center",
          width: 120
        },
        {
          title: "操作",
          key: "operation",
          align: "center",
          fixed: "right",
          width: 200,
          render: (h, params) => {
            return h("div", [
              h(
                "Button",
                {
                  props: {
                    type: "text",
                    size: "small"
                  },
                  on: {
                    click: () => {
                      this.Appraisal(params.row);
                    }
                  }
                },
                "查看测评"
              ),
              h(
                "Button",
                {
                  props: {
                    type: "text",
                    size: "small"
                  },
                  on: {
                    click: () => {
                      this.CallOut(params.row);
                    }
                  }
                },
                "呼出"
              )
            ]);
          }
        }
      ],
      row: "",
      type: "",
      showMod: false
    };
  },
  watch: {
    formItem: {
      deep: true,
      handler(newName, oldName) {
        window.setTimeout(() => {
          this.getUserData();
        }, 200);
      }
    },
    refresh: {
      deep: true,
      handler(newName, oldName) {
        this.getUserData();
        this.setRefresh(false);
      }
    }
  },
  methods: {
    // 关闭窗口状态
    changeShowMod(val) {
      this.showMod = val;
      this.type = "";
    },
    // 呼出
    CallOut(row) {
      this.showMod = true;
      this.row = row;
      this.type = "CallOut";
    },
    // 查看测评
    Appraisal(row) {
      this.showMod = true;
      this.row = row;
      this.type = "Appraisal";
    },
    // 签到
    Signin(row) {
      this.showMod = true;
      this.row = row;
      this.type = "Signin";
    },
    // 取消预约
    Cancelreservation(row) {
      this.showMod = true;
      this.row = row;
      this.type = "Cancelreservation";
    },
    // 点击清除选项
    deleteFormData() {
      this.formItem = {
        page: 1, // 页码
        page_num: "10" // 每页条数
      };
    },
    // 转换date
    changeCourseData(time) {
      this.formItem.date_start_time = time[0];
      this.formItem.date_end_time = time[1];
    },
    // 转换date
    changeSubmissionTime(time) {
      this.formItem.create_start_time = time[0];
      this.formItem.create_end_time = time[1];
    },
    // 转换date
    changeAllocateTimeDate(time) {
      this.formItem.create_st_time = time[0];
      this.formItem.create_en_time = time[1];
    },
    // 设置当前页码
    changePages(val) {
      this.formItem.page = val;
    },
    // 设置mode搜索词汇
    formData(val) {
      this.mode = val;
    },
    ...mapMutations(["setCurrentPages", "setSelectState", "setRefresh"]),
    // 点击选项卡切换触发
    changeTab(value) {
      this.value = value;
      if (this.value === "name3") {
        this.deleteFormData();
        this.columns = this.columns2;
        this.formItem.list_type = 3;
        this.getUserData();
      } else if (this.value === "name2") {
        this.deleteFormData();
        this.columns = this.columns1;
        this.formItem.list_type = 2;
        this.getUserData();
      } else if (this.value === "name1") {
        this.deleteFormData();
        this.columns = this.columns1;
        this.formItem.list_type = 1;
        this.getUserData();
      }
    },
    // 获取用户信息
    async getUserData() {
      this.isLoading = true;
      let res = await this.$request({
        method: "post",
        url: MYRESERVATION,
        data: qs.stringify(this.formItem)
      });

      let links = res.data.data.links;
      // 设置搜索选项
      this.setSelectState(links);
      this.dataList = res.data.data.data;
      this.dataList.map(item => {
        // 显示用户数据并把对应年级科目班级类型转变形式
        item.subject = this.selectState.subject[item.subject];
        item.grade = this.selectState.grade[item.grade];
        item.type = this.selectState.type[item.type];
        item.stateBtn = item.appoint_status == 1 ? true : false;
        item.appoint_status = this.selectState.appointBtn[item.appoint_status];
      });
      this.setCurrentPages(this.dataList);
      // 设置页码
      this.total = links.total;
      this.per_page = links.per_page;
      this.current_page = links.current_page;
      this.last_page = links.last_page;

      this.isLoading = false;
    },
    // 获取select状态栏信息
    async getSelectData() {
      let res = await this.$request({
        url: SCREENLIST
      });
      this.setSelectState(res.data.data.screen_list);
    }
  },
  created() {
    this.getSelectData();
    // this.getUserData();
    this.columns = this.columns1;
  }
};
</script>

<style scoped>
.card {
  margin: 5px;
  overflow: hidden;
}
</style>
<style>
/* 状态模式 */
/* 已上课 */
.state-haveClass {
  width: 80px;
  height: 30px;
  line-height: 30px;
  color: #fff;
  border-radius: 15px;
  margin: 0 auto;
  background-color: #f19736;
}
/* 待上课 */
.state-forClass {
  width: 80px;
  height: 30px;
  line-height: 30px;
  color: #fff;
  border-radius: 15px;
  margin: 0 auto;
  background-color: #00cc66;
}
/* 缺席 */
.state-absent {
  width: 80px;
  height: 30px;
  line-height: 30px;
  color: #fff;
  border-radius: 15px;
  margin: 0 auto;
  background-color: #999900;
}
/* 已取消 */
.state-canceledCanc {
  width: 80px;
  height: 30px;
  line-height: 30px;
  border: 1px solid #ff0000;
  color: #ff0000;
  margin: 0 auto;
}
</style>