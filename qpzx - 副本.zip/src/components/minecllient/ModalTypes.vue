<template>
  <div class="box">modal</div>
</template>

<script>
export default {
  props: ["modalTypes"],
  mounted(){
    console.log(this.modalTypes)
  }
}
</script>

<style>

</style>