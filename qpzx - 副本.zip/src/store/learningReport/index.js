export default {
	state: {
		dataList: {}
	},
	mutations: {
		setLearningReport(state,data) {
			state.dataList = data
		},
	},
	actions: {

	}
}