const HOME = "http://liveh5.canpoint.net/index" //M站首页

const REPID ="http://liveh5.canpoint.net/code_receive" //快捷登陆
const PASSOWRD ="http://liveh5.canpoint.net/password_receive" //密码登陆
const SEND = "http://liveh5.canpoint.net/send_code" //发送验证码
const ISSIGNIN = "http://liveh5.canpoint.net/mobile_exits" //是否已经注册
const SIGNIN = "http://liveh5.canpoint.net/register" //注册
const UPDATEPASSWORD = "http://liveh5.canpoint.net/modify_password" //修改密码

const UESR_DATA = 'http://liveh5.canpoint.net/personal' //用户信息
const UPDATE_USER = "http://liveh5.canpoint.net/update_data" //修改个人信息
const ORDER_LIST = "http://liveh5.canpoint.net/personal" //订单课程列表
const DRAW = "http://liveh5.canpoint.net/is_give" //是否免费领取
const GETDRAW = "http://liveh5.canpoint.net/give_class" //免费领取微课

const DATALIST = "http://liveh5.canpoint.net/material_list" //资料列表
const DATACHILDER = "http://liveh5.canpoint.net/material_detail" //资料合集

const FENXIANG = "http://liveh5.canpoint.net/poster" //分享海报
const CLASSIFY = "http://liveh5.canpoint.net/account_sign" //注册附加信息
const DATALISTS = "http://liveh5.canpoint.net/subject_info" //详情页
const ORDER = "http://liveh5.canpoint.net/create_order" //支付
const ADDSITE = "http://liveh5.canpoint.net/create_address" //新建地址
const ADDRESS = "http://liveh5.canpoint.net/address_list" //地址列表
const DELADDRESS = "http://liveh5.canpoint.net/update_address" //删除/修改地址

const SMALL = "http://liveh5.canpoint.net/subject_list?type=2" //免费课程列表

const DOWNSPOUT = "http://liveh5.canpoint.net/book"//落地页
const VIDEO_LIST = "http://liveh5.canpoint.net/book_video"//视频列表页
const CLASS_LIST = "http://liveh5.canpoint.net/book_video"//课
export {
  CLASS_LIST,
  VIDEO_LIST,
  DOWNSPOUT,
  SMALL,
  HOME,
  SEND,
  UESR_DATA,
  UPDATE_USER,
  ORDER_LIST,
  DRAW,
  GETDRAW,
  DATALIST,
  FENXIANG,
  CLASSIFY,
  DATALISTS,
  REPID,
  PASSOWRD,
  ORDER,
  ADDSITE,
  ADDRESS,
  DELADDRESS,
  DATACHILDER,
  ISSIGNIN,
  SIGNIN,
  UPDATEPASSWORD
}
