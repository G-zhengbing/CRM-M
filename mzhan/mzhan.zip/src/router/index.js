import Vue from 'vue'
import Router from 'vue-router'
import Home from '@/components/Home'
import Databank from '@/components/Databank'
import Personage from '@/components/Personage'
import PersonageData from '@/components/PersonageData'
import Course from '@/components/Course'
import SmallClass from '@/components/SmallClass'
import Order from '@/components/Order'
import Special from '@/components/Special'
import Login from '@/components/Login'
import Classify from '@/components/Classify'
import Data from '@/components/Data'
import Signin from '@/components/Signin'
import Address from '../components/address/Address'
import Addsite from '../components/address/Addsite'
import Databanklist from '../components/Databanklist'
import Bookcode from '../components/book/Bookcode'
import BookList from '../components/book/BookList'
import Bookdetails from '../components/book/Bookdetails'
import storage from '../uilt/storage'
import axios from 'axios'
import store from '../store/index'

Vue.use(Router)

const originalPush = Router.prototype.push
Router.prototype.push = function push(location) {
  return originalPush.call(this, location).catch(err => err)
}

const router = new Router({
  routes: [{
      path: '/',
      name: 'home',
      component: Home
    },
    {
      path: '/login/:type/:uid',
      name: 'login',
      component: Login
    },
    {
      path: '/signin/:id',
      name: 'Signin',
      component: Signin
    },
    {
      path: "/home",
      component: Home
    },
    {
      path: "/home/databank/:id",
      component: Databank
    },
    {
      path: "/personage",
      component: Personage
    },
    {
      path: "/course",
      component: Course
    },
    {
      path: "/smallclass",
      component: SmallClass
    },
    {
      path: "/personagedata",
      component: PersonageData
    },
    {
      path: "/order/:id",
      name: 'Order',
      component: Order
    },
    {
      path: "/special",
      component: Special
    },
    {
      path: "/login",
      name: 'Login',
      component: Login
    },
    {
      path: "/classify",
      component: Classify
    },
    {
      path: "/data",
      component: Data
    },
    {
      path: "/address",
      name: "Address",
      component: Address
    },
    {
      path: "/addsite",
      name: "Addsite",
      component: Addsite
    },
    {
      path: "/data/databanklist/:id",
      name: "Databanklist",
      component: Databanklist
    },
    {
      path: "/bookcode/:id",
      name: "Bookcode",
      component: Bookcode
    },
    {
      path: "/booklist/:id",
      name: "BookList",
      component: BookList
    },
    {
      path: "/bookdetails/:id/:type",
      name: "Bookdetails",
      component: Bookdetails
    }
  ]
})

// router.beforeEach( (to, from, next) => {
// window.location.href = " https://open.weixin.qq.com/connect/oauth2/authorize?appid=wx406b6ad3a5a9d5b4&redirect_uri=http://www.quanpinzaixian.com&response_type=code&scope=snsapi_base&state=123&connect_redirect=1#wechat_redirect "
// })
// router.beforeEach(async (to, from, next) => {

// var ua = navigator.userAgent.toLowerCase();
// var isWeixin = ua.indexOf("micromessenger") != -1;
// let appid = "wx406b6ad3a5a9d5b4"
// let homeUrl = "http://www.quanpinzaixian.com"
// let encode = encodeURIComponent(homeUrl)
// function getQueryString(name) {
//   var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
//   var r = window.location.search.substr(1).match(reg);
//   if (r != null) return unescape(r[2]);
//   return null;
// }
// window.location.href = `https://open.weixin.qq.com/connect/oauth2/authorize?appid=${store.state.appid}&redirect_uri=${encode}&response_type=code&scope=snsapi_base&state=123#wechat_redirect`;
// storage.saveReurl(getQueryString(window.location.href));
// alert(getQueryString(window.location.href))
// alert(storage.getReurl())
// if (
//   getQueryString(window.location.href) == null ||
//   JSON.stringify(storage.getReurl()) == "{}"
// ) {
//   window.location.replace(
//     `https://open.weixin.qq.com/connect/oauth2/authorize?appid=${appid}&redirect_uri=${encode}&response_type=code&scope=snsapi_base&state=123#wechat_redirect`
//   );
// } else if (
//   JSON.stringify(storage.getReurl()) == "{}" &&
//   getQueryString(window.location.href) == null
// ) {
//   storage.saveReurl(getQueryString(window.location.href));
//   history.back();
// }

// if (isWeixin) {
//   window.location.href = `https://open.weixin.qq.com/connect/oauth2/authorize?appid=${appid}&redirect_uri=${encode}&response_type=code&scope=snsapi_base&state=123#wechat_redirect`
//   store.commit("setCode", window.location.href.split('?')[1].split('&')[0].split('=')[1])
// }



// // let code = window.location.href.split('?')[1].split('&')[0].split('=')[1]

//   // axios({
//   //   method:"get",
//   //   url:`https://api.weixin.qq.com/sns/oauth2/access_token?appid=${appid}&secret=SECRET&code=${code}&grant_type=authorization_code`
//   // }).then(res=>{
//   //   alert(res)
//   // })
//   // if (to.matched.some(recode => recode.meta.noAuth)) {
//   //   next()
//   // } else {
//   //   if (store.state.userInfo.nickname) {
//   //     next()
//   //     return
//   //   }
//   // }

// let redirectUrl = window.location.href
// redirectUrl = encodeURIComponent(redirectUrl)
// const appid = 'wx406b6ad3a5a9d5b4'
// window.location.href = `https://open.weixin.qq.com/connect/oauth2/authorize?appid=${appid}&redirect_uri=${redirectUrl}&response_type=code&scope=snsapi_base&state=123#wechat_redirect`
// store.commit(
//   "setCode",
//   window.location.href
//     .split("?")[1]
//     .split("&")[0]
//     .split("=")[1]
// );
//   if (to.matched.some(recode => recode.meta.noAuth)) {
//     next()
//   } else {
//     const code = window.location.href.split('?')[1].split('&')[0].split('=')[1] // 截取url上的code ,可能没有,则返回''空字符串
//     let res = await api.post('/imsl/user/user-auth', {code}) // 获取用户信息,后端可首先通过cookie,session等判断,没有信息则通过code获取
//     alert(res)
//     // 返回用户信息
//     if (res.code === 200 && res.data.is_auth) {
//       store.commit('setUserInfo', res.data)
//       next()
//     } else {
//       // 此状态根据业务需求 可能不存在
//       if (res.code === 201) {
//         const openid = res.data.openid
//         console.log(openid)
//         store.commit('setOpenid', openid)
//         next('/')
//       }
//       // 上面的获取用户信息接口,如果cookie,session拿不到用户信息,且传递的code为空,则跳转到微信授权页面
//       if (res.code === 202) {
//         console.log(window.location.origin)
//         console.log(to.fullPath)
//         // 这个redirectUrl用 当前页路径或者tof.fullPath(将要进入的路径)
//         let redirectUrl = window.location.href
//         redirectUrl = encodeURI(redirectUrl)
//         console.log(redirectUrl)
//         const appid = 'wx406b6ad3a5a9d5b4'
//         window.location.href = `https://open.weixin.qq.com/connect/oauth2/authorize?appid=${appid}&redirect_uri=${redirectUrl}&response_type=code&scope=snsapi_userinfo&state=123#wechat_redirect`
//       }
//     }
//   }
// })

// router.beforeEach((to, form, next) => {
//   var arr = ['/login']
//   if (arr.includes(to.path) || JSON.stringify(storage.getToken()) != '{}') {
//     next()
//     return
//   } else {
//     return next('/login')
//   }
// })
export default router
