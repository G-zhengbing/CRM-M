<template>
  <div>
    <img src="../../assets/img/loading/timg.gif.gif" alt />
  </div>
</template>
<script>
export default {};
</script>
<style scoped>
div img {
  width: 220px;
  height: 200px;
}
div {
  position: absolute;
  width: 100%;
  height: 100%;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: rgba(0, 0, 0, 0.3);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 999;
}
</style>