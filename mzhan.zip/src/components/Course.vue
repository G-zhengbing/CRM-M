<template>
  <div>
    <header>
      <img src="../assets/img/ju.png" alt />
      <div>
        <img src="../assets/img/ti.png" alt />
      </div>
    </header>
    <section>
      <ul>
        <li>
          <div>
            <p>
              <span>英语</span>【秋（下）】初一英语直播勤学班
            </p>
            <span>9月27日-12月27日每周五18：50-21：00</span>
            <div>
              <span>￥888.00</span>
            </div>
          </div>
        </li>
      </ul>
    </section>
  </div>
</template>

<script>
export default {};
</script>

<style scoped>
section ul li > div > div span {
  color: #ee7428;
  font-size: 18px;
	margin-right: 50px;
}
section ul li > div > div {
  border-top: 1px solid rgba(241, 241, 241, 1);
  position: absolute;
  bottom: 0;
  left: 0;
  width: 100%;
  height: 60px;
  line-height: 60px;
	text-align: right;
}
section ul li > div > span {
  color: #999;
  margin-top: 18px;
  font-size: 0.24rem;
  margin-left: 0.133333rem;
  display: inline-block;
}
section ul li > div p {
  color: #333;
  display: flex;
  align-items: center;
  margin-top: 8px;
  margin-left: 10px;
  font-size: 20px;
}
section ul li > div p span {
  display: inline-block;
  background: #ee7428;
  color: #fff;
  border-radius: 0.09rem;
  font-size: 20px;
  width: 0.93rem;
  height: 0.43rem;
  line-height: 0.43rem;
  text-align: center;
}
section ul li > div {
  margin: 10px 18px;
}
section ul li:last-child{
	margin-bottom: 40px;
}
section ul li {
  height: 258px;
  background: rgba(255, 255, 255, 1);
  box-shadow: 0px 2px 4px 0px rgba(29, 29, 29, 0.15);
  border-radius: 6px;
  margin-top: 24px;
  position: relative;
}
section ul {
  display: flex;
  flex-direction: column;
}
section {
  background: #fff;
  margin: 0 20px;
}
header div {
  margin: 0 20px;
  position: absolute;
  top: 50%;
  left: 50%;
  margin-top: -40px;
  margin-left: -356px;
}
header div img {
  height: 80px;
  width: 100%;
  position: relative;
}
header > img {
  height: 160px;
  width: 100%;
}
header {
  height: 160px;
  width: 100%;
  position: relative;
}
</style>